# PythonNetworkRestaurant
Python Network Restaurant Ordering systems

แก้ ip ให้ถูกต้อง

config_counter.csv (ระบุ IP ของไฟล์ kitchen.py) 

config_kitchen.csv (ระบุ IP ของไฟล์ kitchen.py และ waiting.py)

config_waiting.csv (ระบุ IP ของไฟล์ waiting.py)

วิธีการรันไฟล์ให้รันตามลำดับดังนี้

1- kitchen.py
2- counter.py
3- waiting.py
